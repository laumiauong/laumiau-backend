create function atualizar_status_animal() returns trigger
    language plpgsql
as
$$
BEGIN
UPDATE animal
SET status = 'ADOTADO'
WHERE id = NEW.animal_id;
RETURN NEW;
END;
$$;

alter function atualizar_status_animal() owner to postgres;

