create function reverter_status_animal() returns trigger
    language plpgsql
as
$$
BEGIN
UPDATE animal
SET status = 'DISPONIVEL'
WHERE id = OLD.animal_id;
RETURN OLD;
END;
$$;

alter function reverter_status_animal() owner to postgres;

