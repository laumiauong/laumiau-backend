create function validar_idade_animal() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.idade_meses < 0 THEN
        RAISE EXCEPTION 'Idade do animal não pode ser negativa!';
END IF;
RETURN NEW;
END;
$$;

alter function validar_idade_animal() owner to postgres;

